package fodastico.channel.Fake;

import java.util.ArrayList;
import java.util.HashMap;
import org.bukkit.entity.Player;

public class FakeManager
{
  @SuppressWarnings({ "rawtypes", "unchecked" })
public static ArrayList<String> fakes = new ArrayList();
  @SuppressWarnings({ "unchecked", "rawtypes" })
public static HashMap<Player, String> fake = new HashMap();
  @SuppressWarnings({ "rawtypes", "unchecked" })
public static HashMap<Player, String> realName = new HashMap();}

