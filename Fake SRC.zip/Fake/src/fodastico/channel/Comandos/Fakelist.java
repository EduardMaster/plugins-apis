package fodastico.channel.Comandos;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import fodastico.channel.Fake.FakeManager;


public class Fakelist
implements Listener, CommandExecutor
{
@SuppressWarnings("deprecation")
public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
{
if (!(sender instanceof Player)) {
	  sender.sendMessage("�c�l(!) �cSomente jogadores podem executar este comando.");
	  return true;
	  }
  if (cmd.getName().equalsIgnoreCase("fakelist"))
  if (!(sender.hasPermission("cmd.fakelist"))) {
		sender.sendMessage("�cVoc� n�o possui permiss�o para ver jogadores com nick fake.");
		return true;
	  }
   {
    Player p = (Player)sender;
    if (args.length == 0)
   {
		for (Player jogadores : Bukkit.getOnlinePlayers()) {
			sender.sendMessage("�e�m--�aLista de todos os jogadores de fake.�e�m--");
			if (FakeManager.fake.containsKey(jogadores)) {
				      p.sendMessage("�aJogador: �e" + FakeManager.realName.get(jogadores) + " �aFake: �e" + FakeManager.fake.get(jogadores));          				      
		  }
		}
      }
    }
    return false;
  }
}