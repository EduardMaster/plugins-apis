package fodastico.channel.Comandos;

import java.util.Random;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import fodastico.channel.Fake.FakeManager;
import fodastico.channel.Fake.FakePlayerUtils;
import net.md_5.bungee.api.ChatColor;


public class FakeRamdomEvent {

	  public static String ramdom1 = "zSpop_YT";
	  
	  public static String ramdom2 = "LucasMaster_Br";
	  
	  public static String ramdom3 = "Ludimila123";
	  
	  public static String ramdom4 = "howpayS2";
	  
	  public static String ramdom5 = "zGabrielBrrrr";
	  
	  public static String ramdom6 = "iCarlyyyyy";
	  
	  public static String ramdom7 = "MEUDEUSCAIO";
	  
	  public static String ramdom8 = "NvidiaPlayerrr";
	  
	  public static String ramdom9 = "Xx_iG0D_xX";
	  
	  public static String ramdom10 = "Minato_BR_YT";
	  
	  public static String ramdom11 = "Douglas_YT_BR";
	  
	  public static String ramdom12 = "devarnBrr";	  

		@SuppressWarnings({ "deprecation", "unlikely-arg-type" })
		public static boolean FakeRamdom(Player p) {

		final Random random = new Random();
		switch (random.nextInt(12)) {
		case 1:	
            for (Player jogadores : Bukkit.getOnlinePlayers()) 
 		    if (jogadores.getName().contains(ramdom1)) {
 		    FakeRamdom(p);
 	        return true;
 			}
            if (FakeManager.fakes.contains(ramdom1)) {
             FakeRamdom(p);
             return true;
            }
            try
            {
            p.chat("/fake #");
            FakeManager.fakes.add(ramdom1);
            FakeManager.fake.put(p, ramdom1);
            FakeManager.realName.put(p, p.getName());
            FakePlayerUtils.changePlayerName(p, ramdom1);
            FakePlayerUtils.changePlayerSkin(p, ramdom1, Bukkit.getOfflinePlayer(ramdom1).getUniqueId());
            p.sendMessage(ChatColor.GREEN + "Seu nick foi alterado para " + ramdom1 + "!");
            }
            catch (Exception exception)
            {
            p.sendMessage(ChatColor.GREEN + "Seu novo nick � " + ChatColor.YELLOW + ramdom1);
            return true;
            }
			break;
		case 2:
            for (Player jogadores : Bukkit.getOnlinePlayers()) 
 		    if (jogadores.getName().contains(ramdom2)) {
 		    FakeRamdom(p);
 	        return true;
 			}
            if (FakeManager.fakes.contains(ramdom2)) {
             FakeRamdom(p);
             return true;
            }
            try
            {
            p.chat("/fake #");            	
            FakeManager.fakes.add(ramdom2);
            FakeManager.fake.put(p, ramdom2);
            FakeManager.realName.put(p, p.getName());
            FakePlayerUtils.changePlayerName(p, ramdom2);
            FakePlayerUtils.changePlayerSkin(p, ramdom2, Bukkit.getOfflinePlayer(ramdom2).getUniqueId());
            p.sendMessage(ChatColor.GREEN + "Seu nick foi alterado para " + ramdom2 + "!");
            }
            catch (Exception exception)
            {
            p.sendMessage(ChatColor.GREEN + "Seu novo nick � " + ChatColor.YELLOW + ramdom2);
            return true;
            }
			break;
		case 3:
            for (Player jogadores : Bukkit.getOnlinePlayers()) 
 		    if (jogadores.getName().contains(ramdom3)) {
 		    FakeRamdom(p);
 	        return true;
 			}
            if (FakeManager.fakes.contains(ramdom3)) {
             FakeRamdom(p);
             return true;
            }
            try
            {
            p.chat("/fake #");	
            FakeManager.fakes.add(ramdom3);
            FakeManager.fake.put(p, ramdom3);
            FakeManager.realName.put(p, p.getName());
            FakePlayerUtils.changePlayerName(p, ramdom3);
            FakePlayerUtils.changePlayerSkin(p, ramdom3, Bukkit.getOfflinePlayer(ramdom3).getUniqueId());
            p.sendMessage(ChatColor.GREEN + "Seu nick foi alterado para " + ramdom3 + "!");
            }
            catch (Exception exception)
            {
            p.sendMessage(ChatColor.GREEN + "Seu novo nick � " + ChatColor.YELLOW + ramdom3);
            return true;
            }
			break;
		case 4:
            for (Player jogadores : Bukkit.getOnlinePlayers()) 
 		    if (jogadores.getName().contains(ramdom4)) {
 		    FakeRamdom(p);
 	        return true;
 			}
            if (FakeManager.fakes.contains(ramdom4)) {
             FakeRamdom(p);
             return true;
            }
            try
            {
            p.chat("/fake #");	
            FakeManager.fakes.add(ramdom4);
            FakeManager.fake.put(p, ramdom4);
            FakeManager.realName.put(p, p.getName());
            FakePlayerUtils.changePlayerName(p, ramdom4);
            FakePlayerUtils.changePlayerSkin(p, ramdom4, Bukkit.getOfflinePlayer(ramdom4).getUniqueId());
            p.sendMessage(ChatColor.GREEN + "Seu nick foi alterado para " + ramdom4 + "!");
            }
            catch (Exception exception)
            {
            p.sendMessage(ChatColor.GREEN + "Seu novo nick � " + ChatColor.YELLOW + ramdom4);
            return true;
            }
			break;
		case 5:
            for (Player jogadores : Bukkit.getOnlinePlayers()) 
 		    if (jogadores.getName().contains(ramdom5)) {
 		    FakeRamdom(p);
 	        return true;
 			}
            if (FakeManager.fakes.contains(ramdom5))
            {
             FakeRamdom(p);
             return true;
            }
            try
            {
            p.chat("/fake #");
            FakeManager.fakes.add(ramdom5);
            FakeManager.fake.put(p, ramdom5);
            FakeManager.realName.put(p, p.getName());
            FakePlayerUtils.changePlayerName(p, ramdom5);
            FakePlayerUtils.changePlayerSkin(p, ramdom5, Bukkit.getOfflinePlayer(ramdom5).getUniqueId());
            p.sendMessage(ChatColor.GREEN + "Seu nick foi alterado para " + ramdom5 + "!");
            }
            catch (Exception exception)
            {
            p.sendMessage(ChatColor.GREEN + "Seu novo nick � " + ChatColor.YELLOW + ramdom5);
            return true;
            }
			break;
		case 6:
            for (Player jogadores : Bukkit.getOnlinePlayers()) 
 		    if (jogadores.getName().contains(ramdom6)) {
 		    FakeRamdom(p);
 	        return true;
 			}
            if (FakeManager.fakes.contains(ramdom6))
            {
             FakeRamdom(p);
             return true;
            }
            try
            {
            p.chat("/fake #");
            FakeManager.fakes.add(ramdom6);
            FakeManager.fake.put(p, ramdom6);
            FakeManager.realName.put(p, p.getName());
            FakePlayerUtils.changePlayerName(p, ramdom6);
            FakePlayerUtils.changePlayerSkin(p, ramdom6, Bukkit.getOfflinePlayer(ramdom6).getUniqueId());
            p.sendMessage(ChatColor.GREEN + "Seu nick foi alterado para " + ramdom6 + "!");
            }
            catch (Exception exception)
            {
            p.sendMessage(ChatColor.GREEN + "Seu novo nick � " + ChatColor.YELLOW + ramdom6);
            return true;
            }
			break;
		case 7:
            for (Player jogadores : Bukkit.getOnlinePlayers()) 
 		    if (jogadores.getName().contains(ramdom7)) {
 		    FakeRamdom(p);
 	        return true;
 			}
            if (FakeManager.fakes.contains(ramdom7))
            {
             FakeRamdom(p);
             return true;
            }
            try
            {
            p.chat("/fake #");
            FakeManager.fakes.add(ramdom7);
            FakeManager.fake.put(p, ramdom7);
            FakeManager.realName.put(p, p.getName());
            FakePlayerUtils.changePlayerName(p, ramdom7);
            FakePlayerUtils.changePlayerSkin(p, ramdom7, Bukkit.getOfflinePlayer(ramdom7).getUniqueId());
            p.sendMessage(ChatColor.GREEN + "Seu nick foi alterado para " + ramdom7 + "!");
            }
            catch (Exception exception)
            {
            p.sendMessage(ChatColor.GREEN + "Seu novo nick � " + ChatColor.YELLOW + ramdom7);
            return true;
            }
			break;
		case 8:
            for (Player jogadores : Bukkit.getOnlinePlayers()) 
 		    if (jogadores.getName().contains(ramdom8)) {
 		    FakeRamdom(p);
 	        return true;
 			}
            if (FakeManager.fakes.contains(ramdom8))
            {
             FakeRamdom(p);
             return true;
            }
            try
            {
            p.chat("/fake #");
            FakeManager.fakes.add(ramdom8);
            FakeManager.fake.put(p, ramdom8);
            FakeManager.realName.put(p, p.getName());
            FakePlayerUtils.changePlayerName(p, ramdom8);
            FakePlayerUtils.changePlayerSkin(p, ramdom8, Bukkit.getOfflinePlayer(ramdom8).getUniqueId());
            p.sendMessage(ChatColor.GREEN + "Seu nick foi alterado para " + ramdom8 + "!");
            }
            catch (Exception exception)
            {
            p.sendMessage(ChatColor.GREEN + "Seu novo nick � " + ChatColor.YELLOW + ramdom8);
            return true;
            }
			break;
		case 9:
            for (Player jogadores : Bukkit.getOnlinePlayers()) 
 		    if (jogadores.getName().contains(ramdom9)) {
 		    FakeRamdom(p);
 	        return true;
 			}
            if (FakeManager.fakes.contains(ramdom9))
            {
             FakeRamdom(p);
             return true;
            }
            try
            {
            p.chat("/fake #");
            FakeManager.fakes.add(ramdom9);
            FakeManager.fake.put(p, ramdom9);
            FakeManager.realName.put(p, p.getName());
            FakePlayerUtils.changePlayerName(p, ramdom9);
            FakePlayerUtils.changePlayerSkin(p, ramdom9, Bukkit.getOfflinePlayer(ramdom9).getUniqueId());
            p.sendMessage(ChatColor.GREEN + "Seu nick foi alterado para " + ramdom9 + "!");
            }
            catch (Exception exception)
            {
            p.sendMessage(ChatColor.GREEN + "Seu novo nick � " + ChatColor.YELLOW + ramdom9);
            return true;
            }
			break;
		case 10:
            for (Player jogadores : Bukkit.getOnlinePlayers()) 
 		    if (jogadores.getName().contains(ramdom10)) {
 		    FakeRamdom(p);
 	        return true;
 			}
            if (FakeManager.fakes.contains(ramdom10))
            {
             FakeRamdom(p);
             return true;
            }
            try
            {
            p.chat("/fake #");
            FakeManager.fakes.add(ramdom10);
            FakeManager.fake.put(p, ramdom10);
            FakeManager.realName.put(p, p.getName());
            FakePlayerUtils.changePlayerName(p, ramdom10);
            FakePlayerUtils.changePlayerSkin(p, ramdom10, Bukkit.getOfflinePlayer(ramdom10).getUniqueId());
            p.sendMessage(ChatColor.GREEN + "Seu nick foi alterado para " + ramdom10 + "!");
            }
            catch (Exception exception)
            {
            p.sendMessage(ChatColor.GREEN + "Seu novo nick � " + ChatColor.YELLOW + ramdom10);
            return true;
            }
			break;
		case 11:
			FakePlayerUtils.changePlayerName(p, (String)FakeManager.realName.get(p));
            for (Player jogadores : Bukkit.getOnlinePlayers()) 
 		    if (jogadores.getName().contains(ramdom11)) {
 		    FakeRamdom(p);
 	        return true;
 			}
            if (FakeManager.fakes.contains(ramdom11))
            {
             FakeRamdom(p);
             return true;
            }
            try
            {
            p.chat("/fake #");
            FakeManager.fakes.add(ramdom11);
            FakeManager.fake.put(p, ramdom11);
            FakeManager.realName.put(p, p.getName());
            FakePlayerUtils.changePlayerName(p, ramdom11);
            FakePlayerUtils.changePlayerSkin(p, ramdom11, Bukkit.getOfflinePlayer(ramdom11).getUniqueId());
            p.sendMessage(ChatColor.GREEN + "Seu nick foi alterado para " + ramdom11 + "!");
            FakePlayerUtils.changePlayerName(p, (String)FakeManager.realName.get(p));
            }
            catch (Exception exception)
            {
            p.sendMessage(ChatColor.GREEN + "Seu novo nick � " + ChatColor.YELLOW + ramdom11);
            return true;
            }
			break;
		case 12:
            for (Player jogadores : Bukkit.getOnlinePlayers()) 
 		    if (jogadores.getName().contains(ramdom12)) {
 		    FakeRamdom(p);
 	        return true;
 			}
            if (FakeManager.fakes.contains(ramdom12)) {           
             FakeRamdom(p);
             return true;
            }
            try
            {
            p.chat("/fake #");
            FakeManager.fakes.add(ramdom12);
            FakeManager.fake.put(p, ramdom12);
            FakeManager.realName.put(p, p.getName());
            FakePlayerUtils.changePlayerName(p, ramdom12);
            FakePlayerUtils.changePlayerSkin(p, ramdom12, Bukkit.getOfflinePlayer(ramdom12).getUniqueId());
            p.sendMessage(ChatColor.GREEN + "Seu nick foi alterado para " + ramdom12 + "!");
            }
            catch (Exception exception)
            {
            p.sendMessage(ChatColor.GREEN + "Seu novo nick � " + ChatColor.YELLOW + ramdom12);
            return true;
            }
			break;
		default:
		}
		return true;	
    }
}