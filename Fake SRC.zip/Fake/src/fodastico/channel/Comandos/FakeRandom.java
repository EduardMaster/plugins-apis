package fodastico.channel.Comandos;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import fodastico.channel.Fake.FakeManager;
import fodastico.channel.Fake.FakePlayerUtils;
import net.md_5.bungee.api.ChatColor;



public class FakeRandom implements Listener, CommandExecutor {

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (!(sender instanceof Player)) {
			sender.sendMessage("�bPrecisa ser um Player para usar esse comando.");
			return true;
		}
		final Player p = (Player) sender;
		if (!p.hasPermission("cmd.fakerandom")) {
			sender.sendMessage("�cVoc� nao possui permissao.");
			return true;
		}
		if (args.length == 0) {	
			FakeRamdomEvent.FakeRamdom(p);
        }
        else
        {
          if (FakeManager.fake.containsKey(p))
          {
              FakeManager.fakes.remove(FakeManager.fake.get(p));
              FakeManager.fake.remove(p);
              FakePlayerUtils.changePlayerName(p, (String)FakeManager.realName.get(p));
              FakeManager.realName.remove(p);
        	  p.setDisplayName("�7" + ChatColor.GRAY + p.getName());
        	  p.setPlayerListName("�7" + ChatColor.GRAY + p.getName());
            return true;
          }
		return true;
		
		
}
		return false;
}
}