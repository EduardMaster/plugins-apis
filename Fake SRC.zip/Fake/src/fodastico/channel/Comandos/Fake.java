package fodastico.channel.Comandos;

import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import fodastico.channel.Fake.FakeManager;
import fodastico.channel.Fake.FakePlayerUtils;


public class Fake
  implements CommandExecutor
{
  public static String nickname1;
  
  public static String nickname2;

@SuppressWarnings("deprecation")
public boolean onCommand(CommandSender commandSender, Command command, String label, String[] args)
  {
    if ((commandSender instanceof Player))
    {
      Player player = (Player)commandSender;
      if (command.getName().equalsIgnoreCase("fake")) {
        if (player.hasPermission("cmd.fake"))
        {
          if (args.length == 0)
          {
            player.sendMessage(ChatColor.GREEN + "Use /fake [nick]");
            player.sendMessage(ChatColor.GREEN + "Para voltar ao nick original use /fake #");
            return false;
          }           
          if (args.length == 1) {
            if (args[0].toLowerCase().equals("#"))
            {
              if (FakeManager.fake.containsKey(player)) {
                try
                {
                FakeManager.fakes.remove(FakeManager.fake.get(player));
                FakeManager.fake.remove(player);
                FakePlayerUtils.changePlayerName(player, (String)FakeManager.realName.get(player));
                FakeManager.realName.remove(player);
          		player.setDisplayName("�7" + ChatColor.GRAY + player.getName());
          		player.setPlayerListName("�7" + ChatColor.GRAY + player.getName());
                player.sendMessage(ChatColor.GREEN + "Fake resetado/atualizado!");
                  return true;
                }
                catch (Exception exception)
                {
                  player.sendMessage(ChatColor.GREEN + "Fake resetado/atualizado!");
                  return true;
                }
              }
              player.sendMessage(ChatColor.GREEN + "Fake resetado/atualizado!");
            }
            else
            {
              if (FakeManager.fake.containsKey(player))
              {
                player.sendMessage(ChatColor.RED + "Voce ja esta usando um fake.");
                return true;
              }
              String nickname = args[0];
              nickname1 = args[0];
              nickname2 = args[0];
              if (!FakePlayerUtils.validateName(nickname))
              {
                player.sendMessage(ChatColor.RED + "O nick escolhido possui caraters nao permitidos.");
                return true;
              }
              for (Player jogadores : Bukkit.getOnlinePlayers()) 
   			  if (jogadores.getName().contains(nickname)) {
   	               player.sendMessage("�cVoc� nao pode usar o nick de um jogador online.");
   	          return true;
   			  }
              if (FakeManager.fakes.contains(nickname))
              {
                player.sendMessage(ChatColor.GRAY + "Ops, parece que alguem j� esta usando este fake, de /fakelist para ver.");
                return true;
              }
              try
              {
                FakeManager.fakes.add(nickname);
                FakeManager.fake.put(player, nickname);
                FakeManager.realName.put(player, player.getName());
                FakePlayerUtils.changePlayerName(player, nickname);
                FakePlayerUtils.changePlayerSkin(player, nickname, Bukkit.getOfflinePlayer(nickname).getUniqueId());
                player.sendMessage(ChatColor.GREEN + "Seu nick foi alterado para " + nickname + "!");
              }
              catch (Exception exception)
              {
                player.sendMessage(ChatColor.GREEN + "Seu novo nick � " + ChatColor.YELLOW + nickname);
                return true;
              }
            }
          }
        }
        else
        {
          player.sendMessage("�cVoc� n�o tem permiss�o para utilizar o nick fake.");
        }
      }
 
    return false;
}
	return false;
}
}

