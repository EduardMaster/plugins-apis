package fodastico.channel.Main;

import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import fodastico.channel.Comandos.Fake;
import fodastico.channel.Comandos.FakeRamdomEvent;
import fodastico.channel.Comandos.FakeRandom;
import fodastico.channel.Comandos.Fakelist;


public class Main extends JavaPlugin{
	
	public static Main main;
	public static Plugin instance;
	public static Plugin plugin;
	public static Plugin getPlugin(){
		return plugin;
	}
	
	public void onEnable() {
		main = this;
		getCommand("fake").setExecutor(new Fake());
		getCommand("fakelist").setExecutor(new Fakelist());
		getCommand("fakerandom").setExecutor(new FakeRandom());
			
		}

	@SuppressWarnings("unused")
	private void RegistrarEventos (){
		
		getServer().getPluginManager().registerEvents((Listener) new FakeRamdomEvent(), this);
	}
	
		@SuppressWarnings("unused")
		private Main getInstace() {
			// TODO Auto-generated method stub
			return null;
		}

	}