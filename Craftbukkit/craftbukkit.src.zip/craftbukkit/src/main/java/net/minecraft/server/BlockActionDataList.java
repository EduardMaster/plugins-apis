package net.minecraft.server;

import java.util.ArrayList;

// CraftBukkit - imported class because the constructor is package private
class BlockActionDataList extends ArrayList {

    private BlockActionDataList() {}

    BlockActionDataList(BananaAPI bananaapi) {
        this();
    }
}
