package org.bukkit.craftbukkit.generator;

import net.minecraft.server.World;

/**
 * This class is useless. Just fyi.
 */
public class SkyLandsChunkGenerator extends NormalChunkGenerator {
    public SkyLandsChunkGenerator(World world, long seed) {
        super(world, seed);
    }
}
